# Complaint-management-system-web-Jsp-and-Servlet

Complaint management system is a universality complaint management system where you can through complaint to the department 
for specific problems. And you also get the reply that given by teacher. This application has Teachers and Students dashboard.
Teachers can see the complaints type range that help teachers to know university actual problems. We developed by Core Java,JSP 
and Servlets with MVC framework and used in front end HTML, CSS, JS, jQuery, Bootstrap. As server we used Tomcat & MySQL database.
